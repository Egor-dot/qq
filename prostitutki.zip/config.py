token='1674856897:AAFPkHUNhNrK7UIxYYvFgUQCAnvK3PkfCWo'
admin=1456385283

minimalka = 500
maximalka = 20000
vxodadmin='D9xan' #Слово для входа в админ панель (Доступно только для админов)
vxodworker='/infoscam'#Слово для входа в воркер панель (Доступно только для всех)
zalety = -1001494842956
bot_username = "losypusy_bot"


poderjka = "@LoosyPussySupport" #аккаунт техподдержки

maxpromo = 5000 #максимальная сумма промокода которую могут создать воркеры


